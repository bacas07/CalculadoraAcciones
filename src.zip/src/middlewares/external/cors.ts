import cors from 'cors';
export default cors();
