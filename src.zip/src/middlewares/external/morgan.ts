import morgan from 'morgan'
export default morgan('dev')